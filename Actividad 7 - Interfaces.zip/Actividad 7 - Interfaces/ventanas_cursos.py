import tkinter as tk

class VentanasCursos:
    @staticmethod
    def ventana_insertar():
        ventana_insertar = tk.Toplevel()
        ventana_insertar.title("Agregar Curso")
        ventana_insertar.geometry("500x500")

        label_nombre = tk.Label(ventana_insertar, text="Nombre:")
        label_nombre.pack(pady=5)

        input_nombre = tk.Entry(ventana_insertar)
        input_nombre.pack(pady=5)

        label_descripcion = tk.Label(ventana_insertar, text="Descripción:")
        label_descripcion.pack(pady=5)

        input_descripcion = tk.Entry(ventana_insertar)
        input_descripcion.pack(pady=5)

        label_fecha_inicio = tk.Label(ventana_insertar, text="Fecha de inicio:")
        label_fecha_inicio.pack(pady=5)

        input_fecha_inicio = tk.Entry(ventana_insertar)
        input_fecha_inicio.pack(pady=5)

        label_fecha_fin = tk.Label(ventana_insertar, text="Fecha de fin:")
        label_fecha_fin.pack(pady=5)

        input_fecha_fin = tk.Entry(ventana_insertar)
        input_fecha_fin.pack(pady=5)

        label_profesor = tk.Label(ventana_insertar, text="Profesor:")
        label_profesor.pack(pady=5)

        input_profesor = tk.Entry(ventana_insertar)
        input_profesor.pack(pady=5)

        btn_guardar = tk.Button(
            ventana_insertar,
            text="Guardar",
            command=lambda: print(
                input_nombre.get(),
                input_descripcion.get(),
                input_fecha_inicio.get(),
                input_fecha_fin.get(),
                input_profesor.get(),
            ),
        )
        btn_guardar.pack(pady=20)
